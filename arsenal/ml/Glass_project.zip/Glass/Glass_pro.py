from flask import *
import sqlite3
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import pickle
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from sklearn.ensemble import AdaBoostClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix
import seaborn as sns
from sklearn.metrics import classification_report
from sklearn.metrics import accuracy_score

dbase=sqlite3.connect("Glassdooor_DATABASE.db")

dbase.execute("""CREATE TABLE IF NOT EXISTS MYPRO(
                REGNO INTEGER PRIMARY KEY AUTOINCREMENT,
                NAME TEXT,
                DEPT TEXT,
                COLLEGE TEXT,
                MNO TEXT,
                MAIL TEXT )""")

model=pickle.load(open("Glass.pkl",'rb'))

#print(model)
app=Flask(__name__)

@app.route("/")
def main():
    return render_template("STU_register.html")

@app.route("/login_page")
def login_page():
    return render_template("STU_login.html")


@app.route("/register",methods=["GET","POST"])
def register():
    if request.method=="POST":
        dbase=sqlite3.connect("Glassdooor_DATABASE.db")
        rno=request.form['rno']
        name=request.form['name']
        dept=request.form['dept']
        clg=request.form['clg']
        mno=request.form['mno']
        mail=request.form['mail']
            
        dbase.execute("insert into MYPRO(REGNO,NAME,DEPT,COLLEGE,MNO,MAIL) values(?,?,?,?,?,?)",(rno,name,dept,clg,mno,mail))
        dbase.commit()
        dbase.close()
            
        return render_template("STU_login.html")

@app.route("/login_data" , methods=["GET","POST"])
def login_data():
    if request.method=="POST":
        
        dbase=sqlite3.connect("Glassdooor_DATABASE.db")
        cur=dbase.cursor()
        rno=request.form['rno']
        name=request.form['name']
        cur.execute("select * from MYPRO where REGNO=? and NAME=?",(rno,name))
        data=cur.fetchall()
        print(data)
        return render_template("index.html")
       
    

@app.route("/data",methods=["GET","POST"])
def data():
    if request.method=="POST":
        get_data_1 =float( request.form["myrange"])
        print(type(get_data_1))
        get_data_2 =float( request.form["myRange1"])
        get_data_3 =float( request.form["myRange2"])
        get_data_4 =float( request.form["myRange3"])
        get_data_5 =float( request.form["myRange4"])
        get_data_6 =float( request.form["myRange5"])
        get_data_7 =float( request.form["myRange6"])
        get_data_8 =float( request.form["myRange7"])
        get_data_9 =float( request.form["myRange8"])
        result=model.predict([[get_data_1,get_data_2,get_data_3,get_data_4,get_data_5,get_data_6,get_data_7,get_data_8,get_data_9]])
        resultprob=model.predict_proba([[get_data_1,get_data_2,get_data_3,get_data_4,get_data_5,get_data_6,get_data_7,get_data_8,get_data_9]])
        prob=round(max(resultprob[0])*100,2)
        print(prob," % ",result[0])
        if result[0]==1:
            a='Building Windows Float Processed'
            print(round(max(resultprob[0])*100,2),'% it is ',a)
            return redirect(url_for("output1"))
        elif result[0]==2:
            b='Building Windows NON Float Processed'
            print(round(max(resultprob[0])*100,2),'% it is ',b)
            return redirect(url_for("output2"))
        elif result[0]==3:
            a='Vehicle Windows Float Processed'
            print(round(max(resultprob[0])*100,2),'% it is ',a)
            return redirect(url_for("output3"))
        elif result[0]==5:
            b='Containers'
            print(round(max(resultprob[0])*100,2),'% it is ',b)
            return redirect(url_for("output4"))
        elif result[0]==6:
            a='Tableware'
            print(round(max(resultprob[0])*100,2),'% it is ',a)
            return redirect(url_for("output5"))
        else:
            b='Headlamps'
            print(round(max(resultprob[0])*100,2),'% it is ',b)
            return redirect(url_for("output6"))

        return "if done"
    return "wrong"

@app.route("/output1")
def output1():
    a='Building Windows Float Processed'
    return render_template("output1.html",data=a)

@app.route("/output2")
def output2():
    b='Building Windows NON Float Processed'
    return render_template("output2.html",data=b)

@app.route("/output3")
def output3():
    a='Vehicle Windows Float Processed'
    return render_template("output3.html",data=a)

@app.route("/output4")
def output4():
    b='Containers'
    return render_template("output4.html",data=b)

@app.route("/output5")
def output5():
    a='Tableware'
    return render_template("output5.html",data=a)

@app.route("/output6")
def output6():
    b='Headlamps'
    return render_template("output6.html",data=b)


if __name__=="__main__":
    app.run(debug=True)
    dbase.close()

import random
import numpy as np


lower = ["abcdefghijklmnopqrstuvwxyz"]

print(np.random.choice(lower))

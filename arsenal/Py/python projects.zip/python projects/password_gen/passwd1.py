# password using Tkinter module
import random
import pyperclip
from tkinter import *
from tkinter.ttk import *
from PIL import Image,ImageTk
from tkinter import messagebox

app=Tk()
app.title("Password Generator")
app.geometry("600x400")
app.configure(background="skyblue")
bg_image=Image.open("passwd.jpg")
test_img=ImageTk.PhotoImage(bg_image)
 


var = IntVar()
var1 = IntVar()
password1=StringVar()


# Function for calculation of password
def low():
    entry.delete(0, END)
 
    # Get the length of password
    length = var1.get()
 
    lower = "abcdefghijklmnopqrstuvwxyz"
    upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    digits = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 !@#$%^&*()"
    password = ""
 
    # if strength selected is low
    if var.get() == 1:
        for i in range(0, length):
            password = password + random.choice(lower)
        return password
 
    # if strength selected is medium
    elif var.get() == 0:
        for i in range(0, length):
            password = password + random.choice(upper)
        return password
 
    # if strength selected is strong
    elif var.get() == 3:
        for i in range(0, length):
            password = password + random.choice(digits)
        return password
    else:
        print("Please choose an option")
 
 
# Function for generation of password
def generate():
    password1 = low()
    entry.insert(0, password1)
 
 
# Function for copying password to clipboard
def copy1():
    random_password = entry.get()
    pyperclip.copy(random_password)

def reset():
        entry.delete(0, END)
        #combo.current(0)
 
# Main Function
 
# create GUI window

 
# Title of your GUI window


bg_lb=Label(app,image=test_img)
bg_lb.place(x=10,y=10,relwidth=1,relheight=1)
 
# create label and entry to show
# password generated
Random_password = Label(app, text="Password")
Random_password.grid(row=0)
entry = Entry(app)
entry.grid(row=0, column=1)
 
# create label for length of password
c_label = Label(app, text="Length")
c_label.grid(row=1)
 
# create Buttons Copy which will copy
# password to clipboard and Generate
# which will generate the password
copy_button = Button(app, text="Copy", command=copy1)
copy_button.grid(row=0, column=2)
generate_button = Button(app, text="Generate", command=generate)
generate_button.grid(row=0, column=3)
reset_button=Button(app ,text ='Reset' ,command = reset)
reset_button.grid(row=0,column=4)

# Radio Buttons for deciding the
# strength of password
# Default strength is Medium
radio_low = Radiobutton(app, text="Low", variable=var, value=1)
radio_low.grid(row=1, column=2, sticky='E')
radio_middle = Radiobutton(app, text="Medium", variable=var, value=0)
radio_middle.grid(row=1, column=3, sticky='E')
radio_strong = Radiobutton(app, text="Strong", variable=var, value=3)
radio_strong.grid(row=1, column=4, sticky='E')
#combo = Combobox(app, textvariable=var1)

# Combo Box for length of the password
v1 = DoubleVar()
s1 = Scale( app, variable = v1, 
           from_ = 1, to = 50, 
           orient = HORIZONTAL)
s1.grid(row=1,column=1)

  

##combo.current(0)
##combo.bind('<<ComboboxSelected>>')
##combo.grid(column=1, row=1)
# Start the GUI
app.mainloop()

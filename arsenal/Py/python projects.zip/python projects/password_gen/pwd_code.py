from tkinter import *
from PIL import Image,ImageTk
from tkinter import messagebox
import random
import pyperclip

app=Tk()
app.title("Password Generator")
app.geometry("700x400")
app.configure(background="skyblue")
bg_image=Image.open("pwd.jpg")
test_img=ImageTk.PhotoImage(bg_image)

bg_lb=Label(app,image=test_img)
bg_lb.place(x=0,y=0,relwidth=1,relheight=1)

var = IntVar()
var1 = IntVar()
password1=StringVar()
v1 = IntVar()

def low():
    entry.delete(0, END)
 
    # Get the length of password
    length = var1.get()
 
    lower = "abcdefghijklmnopqrstuvwxyz"
    upper = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
    digits = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789 !@#$%^&*()"
    password = ""
 
    # if strength selected is low
    if var.get() == 1:
        for i in range(0, length):
            password = password + np.random.choice(lower)
        return password
 
    # if strength selected is medium
    elif var.get() == 0:
        for i in range(0, length):
            password = password + random.choice(upper)
        return password
 
    # if strength selected is strong
    elif var.get() == 3:
        for i in range(0, length):
            password = password + random.choice(digits)
        return password
    else:
        print("Please choose an option")




# Function for generation of password
def generate():
    password1 = low()
    entry.insert(0, password1)
 
 
# Function for copying password to clipboard
def copy1():
    random_password = entry.get()
    pyperclip.copy(random_password)

def reset():
    entry.delete(0, END)
    combo.current(0)

def set_len():
    sel =str(var1.get())
    ans.config(text = sel)
    



Random_password = Label(app, text="Password",font=("Georgia",26),bg='skyblue',fg="#3b0508")
Random_password.grid(row=0,column=0,padx=15,pady=15)
entry = Entry(app,font=("lucida 20 bold italic",26),bg='#68acb3')
entry.grid(row=0,column=1,padx=15,pady=15)


c_label = Label(app, text="Length",font=("Georgia",26),bg='skyblue',fg="#3b0508")
c_label.grid(row=1,column=0,padx=15,pady=15)

ans=Label(app,font=("Georgia",26),width=18,bg='#68acb3')
ans.grid(row=1,column=1,padx=15,pady=15)


s1 = Scale( app, variable = var1, 
           from_ = 1, to = 20, 
           orient = HORIZONTAL,bg='skyblue') 
s1.grid(row=2,column=1,padx=15,pady=15)

reset_button=Button(app,command=set_len,text ='Set_length',font=("Georgia",15),bg="#35854c")
reset_button.grid(row=3,column=1,padx=15,pady=15)


copy_button = Button(app, text="Copy", command=copy1,font=("Georgia",26),bg='#40bf21',fg="#3b0508")
copy_button.grid(row=4, column=0)

generate_button = Button(app, text="Generate", command=generate,font=("Georgia",26),bg='#40bf21',fg="#3b0508")
generate_button.grid(row=4, column=1)

reset_button=Button(app ,text ='Reset' ,command = reset,font=("Georgia",26),bg='#40bf21',fg="#3b0508")
reset_button.grid(row=4,column=2)


radio_low = Radiobutton(app, text="Low", variable=var, value=1,font=("Georgia",26),fg="#3b0508",bg='#d44c4c')
radio_low.grid(row=0, column=3, sticky='E')
radio_middle = Radiobutton(app, text="Medium", variable=var, value=0,font=("Georgia",26),fg="#3b0508",bg='#d44c4c')
radio_middle.grid(row=0, column=4, sticky='E')
radio_strong = Radiobutton(app, text="Strong", variable=var, value=3,font=("Georgia",26),fg="#3b0508",bg='#d44c4c')
radio_strong.grid(row=0, column=5, sticky='E')



##r=[]
##choice1 = Radiobutton(app,text=)
##choice1.grid(row=5, column=5, sticky='E')











app.mainloop()

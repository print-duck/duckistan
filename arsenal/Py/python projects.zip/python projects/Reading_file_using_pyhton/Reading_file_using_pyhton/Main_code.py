from tkinter import *
from tkinter import filedialog

from tkinter.filedialog import asksaveasfile
files = [('All Files', '*.*'), 
             ('Python Files', '*.py'),
             ('Text Document', '*.txt')]
app=Tk()
app.title("my app")
app.geometry("800x400")
app.configure(background="skyblue")


def file_Reader():
    input_file = filedialog.askopenfile(defaultextension = files)
    print(input_file)
    read_win = Toplevel(app)
    read_win.geometry("600x300")
    sb = Scrollbar(read_win)  
    sb.pack(side = RIGHT,fill=Y)  
              
    mylist = Listbox(read_win, yscrollcommand = sb.set )  
              
    for line in input_file:  
        mylist.insert(END,  str(line))  
              
    mylist.pack( side = LEFT,fill=BOTH,expand=True)  
    sb.config( command = mylist.yview )  
              
    read_win.mainloop()  
def file_write():
    
    
    
    file = asksaveasfile(filetypes = files, defaultextension = files)
   
       
       
btn1=Button(app,command=file_Reader,text="Read",font=("Georgia",16),bg="green",fg="white",activebackground="red",activeforeground="yellow",width=10,bd=5)
btn1.place(x=200,y=100)


btn2=Button(app,command=file_write,text="Write",font=("Georgia",16),bg="green",fg="white",activebackground="red",activeforeground="yellow",width=10,bd=5)
btn2.place(x=400,y=100)

app.mainloop()

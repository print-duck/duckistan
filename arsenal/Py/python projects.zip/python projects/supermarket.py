from tkinter import*
from tkinter import messagebox
import sqlite3
dbase=sqlite3.connect('supermarket.db')


app=Tk()
app.title('supermarket')
app.geometry('800x600')
app.configure(background='#6ac2e9')

name=StringVar()
product=StringVar()
qty=StringVar()
price=StringVar()

def submit():
      nameval=name.get()
      productval=product.get()
      qtyval=qty.get()
      priceval=price.get()
      
      if nameval and productval and qtyval and priceval:
           dbase.execute(f'''CREATE TABLE IF NOT EXISTS
               {nameval}(
               ID INTEGER PRIMARY KEY AUTOINCREMENT,
               CUSTOMER_NAME TEXT NOT NULL,
               PRODUCT_NAME TEXT NOT NULL,
               QUANTITY TEXT NOT NULL,
               PRICE TEXT NOT NULL)''')
          
           dbase.execute(f'INSERT INTO {nameval}(CUSTOMER_NAME,PRODUCT_NAME,QUANTITY,PRICE)VALUES(?,?,?,?)',(nameval,productval,qtyval,priceval))
           dbase.commit()
           
           messagebox.showinfo('sucess','Products has been registed')

      else:
           messagebox.showerror("ERROR",'Fill all data')


lb1=Label(app,text='Customer Name: ',font=('Arial',28),bg='white',fg='red')
lb1.grid(row=0,column=0,padx=15,pady=15)
ent1=Entry(app,font=('Arial',28),bg='#71a8a6',fg='#0f3332',textvariable=name)
ent1.grid(row=0,column=1,padx=15,pady=15)

lb2=Label(app,text='Product Name : ',font=('Arial',28),bg='white',fg='red')
lb2.grid(row=1,column=0,padx=15,pady=15)
ent2=Entry(app,font=('Arial',28),bg='#71a8a6',fg='#0f3332',textvariable=product)
ent2.grid(row=1,column=1,padx=15,pady=15)

lb3=Label(app,text='Quantity Name : ',font=('Arial',28),bg='white',fg='red')
lb3.grid(row=2,column=0,padx=15,pady=15)
ent3=Entry(app,font=('Arial',28),bg='#71a8a6',fg='#0f3332',textvariable=qty)
ent3.grid(row=2,column=1,padx=15,pady=15)

lb4=Label(app,text='Price',font=('Arial',28),bg='white',fg='red')
lb4.grid(row=4,column=0,padx=15,pady=15)
ent4=Entry(app,font=('Arial',28),bg='#71a8a6',fg='#0f3332',textvariable=price)
ent4.grid(row=4,column=1,padx=15,pady=15)

btn=Button(app,text='submit',font=('Arial',28),bg='#6ac2e9',fg='red',command=submit,activebackground='yellow')
btn.grid(row=5,column=1)






          

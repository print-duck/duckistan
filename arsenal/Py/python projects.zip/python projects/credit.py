from tkinter import*
from tkinter import messagebox
import sqlite3
import datetime
from PIL import Image,ImageTk
app=Tk()
app.geometry('800x600')
app.resizable(width=False,height=False)
app.configure(background='#6bc283')

dbase=sqlite3.connect('Grade checker.db')
dbase.execute('''CREATE TABLE IF NOT EXISTS
               BCA(
               ID INTEGER PRIMARY KEY AUTOINCREMENT,
               NAME TEXT NOT NULL,
               DEPT TEXT UNIQUE,
               REG_NO TEXT UNIQUE NOT NULL,
               OST TEXT NOT NULL,
               JAVA TEXT NOT NULL,
               SE TEXT NOT NULL,
               CN TEXT NOT NULL,
               PYTHON TEXT NOT NULL,
               CREDITS TEXT NOT NULL,
               SGPA TEXT NOT NULL)''')
dbase.commit()


PyVal=StringVar()
JavaVal=StringVar()
OsVal=StringVar()
CnVal=StringVar()
DbmsVal=StringVar()


def submit():
    cred={'S':10,'A':9,'B':8,'C':7,'D':6,'E':5}
    creds_Py=(cred[PyVal.get()])*5
    creds_Java=(cred[JavaVal.get()])*4
    creds_Os=(cred[OsVal.get()])*5
    creds_Cn=(cred[CnVal.get()])*4
    creds_Dbms=(cred[DbmsVal.get()])*3
    exec(f'credi=Label(app,text={creds_Py},font=("Georgia",20),fg="blue")')
    exec('credi.place(x=605,y=150)')
    exec(f'credi=Label(app,text={creds_Java},font=("Georgia",20),fg="blue")')
    exec('credi.place(x=605,y=210)')
    exec(f'credi=Label(app,text={creds_Os},font=("Georgia",20),fg="blue")')
    exec('credi.place(x=605,y=270)')
    exec(f'credi=Label(app,text={creds_Cn},font=("Georgia",20),fg="blue")')
    exec('credi.place(x=605,y=330)')
    exec(f'credi=Label(app,text={creds_Dbms},font=("Georgia",20),fg="blue")')
    exec('credi.place(x=605,y=390)')
    total_credit=creds_Py+creds_Java+creds_Os+creds_Cn+creds_Dbms
    sgpa=total_credit/5
    exec(f'credi=Label(app,text={total_credit},font=("Georgia",20),fg="blue")')
    exec('credi.place(x=605,y=450)')
    exec(f'credi=Label(app,text={sgpa},font=("Georgia",20),fg="blue")')
    exec('credi.place(x=605,y=510)')




lb1=Label(app,text='NAME:',font=('Georgia',20),fg='red')
lb1.place(x=0,y=0)
ent1=Entry(app,font=('Georgia',20),width=10)
ent1.place(x=100,y=0)

lb2=Label(app,text='DEPT:',font=('Georgia',20),fg='red')
lb2.place(x=250,y=0)
ent2=Entry(app,font=('Georgia',20),width=10)
ent2.place(x=340,y=0)

lb3=Label(app,text='REG_NO:',font=('Georgia',20),fg='red')
lb3.place(x=470,y=0)
ent3=Entry(app,font=('Georgia',20),width=10)
ent3.place(x=610,y=0)


lb3=Label(app,text='SUBJECTS',font=('Georgia',20),fg='Black')
lb3.place(x=10,y=80)

lbgd=Label(app,text='GRADE',font=('Georgia',20),fg='Black')
lbgd.place(x=230,y=80)

lb4=Label(app,text='Python',font=('Georgia',25),fg='blue')
lb4.place(x=35,y=150)
ent4=Entry(app,font=('Georgia',25),width=3,textvariable=PyVal)
ent4.place(x=250,y=150)

lb5=Label(app,text='Java',font=('Georgia',25),fg='blue')
lb5.place(x=40,y=210)
ent5=Entry(app,font=('Georgia',25),width=3,textvariable=JavaVal)
ent5.place(x=250,y=210)

lb6=Label(app,text='OS',font=('Georgia',25),fg='blue')
lb6.place(x=40,y=270)
ent6=Entry(app,font=('Georgia',25),width=3,textvariable=OsVal)
ent6.place(x=250,y=270)

lb7=Label(app,text='CN',font=('Georgia',25),fg='blue')
lb7.place(x=40,y=330)
ent7=Entry(app,font=('Georgia',25),width=3,textvariable=CnVal)
ent7.place(x=250,y=330)

lb8=Label(app,text='DBMS',font=('Georgia',25),fg='blue')
lb8.place(x=40,y=390)
ent8=Entry(app,font=('Georgia',25),width=3,textvariable=DbmsVal)
ent8.place(x=250,y=390)


lb9=Label(app, text="Total credit",font=('Georgia',20),fg='black')
lb9.place(x=370,y=450)

lb10=Label(app,text="*MUST FILL ALL THE GRADE IN BLOCK LETTERS*",font=('Georgia',15),fg='black')
lb10.place(x=135,y=560)

lb11=Label(app, text="SGPA",font=('Georgia',20),fg='black')
lb11.place(x=390,y=500)
##

lb12=Label(app, text="CREDIT",font=('Georgia',20),fg='Black')
lb12.place(x=370,y=80)

lb13=Label(app, text="CREDIT_OBTAINED",font=('Georgia',20),fg='Black')
lb13.place(x=500,y=80)

btn=Button(app, text="submit", font=('Georgia',20),fg='Black',bg="green", command=submit)
btn.place(x=120,y=470)

lb14=Label(app,text='5',font=('Georgia',20),fg='blue')
lb14.place(x=415,y=150)

lb7=Label(app,text='4',font=('Georgia',20),fg='blue')
lb7.place(x=415,y=210)

lb7=Label(app,text='5',font=('Georgia',20),fg='blue')
lb7.place(x=415,y=270)

lb7=Label(app,text='4',font=('Georgia',20),fg='blue')
lb7.place(x=415,y=330)

lb7=Label(app,text='3',font=('Georgia',20),fg='blue')
lb7.place(x=415,y=390)





app.mainloop()









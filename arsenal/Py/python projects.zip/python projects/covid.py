from tkinter import*
from tkinter import messagebox
import sqlite3
import datetime
dbase=sqlite3.connect('covid.db')
dbase.execute('''CREATE TABLE IF NOT EXISTS
               DOSE_DETAILS(
               ID INTEGER PRIMARY KEY AUTOINCREMENT,
               NAME TEXT NOT NULL,
               AADHAR_NO TEXT UNIQUE,
               MOBILE_NO TEXT NOT NULL,
               VACCINE_TYPE TEXT NOT NULL,
               DOSES TEXT NOT NULL,
               DATE TEXT NOT NULL)''')
dbase.commit()

app=Tk()
app.title('COVID')
app.geometry('800x400')
app.configure(background='#6ac2e9')

name=StringVar()
aadhar=StringVar()
mobile=StringVar()
aadhar_search=StringVar()
datedata=StringVar()
csv=StringVar()
dose=StringVar()
aadhar_search=StringVar()

def submit():
     nameval=name.get()
     aadharval=aadhar.get()
     mobileval=mobile.get()
     csvval=csv.get()
     doseval=dose.get()

     reg_timeval=datetime.datetime.now()
     print(reg_timeval)
##      print(nameval)
##      print(deptval)
##      print(regnoval)

            
     if doseval=='1':
          output='1st Dose'
          if csvval=='1':
               v_type='CoviShield'
               dbase.execute('INSERT INTO DOSE_DETAILS(NAME,AADHAR_NO,MOBILE_NO,VACCINE_TYPE,DOSES,DATE)VALUES(?,?,?,?,?,?)',(nameval,aadharval,mobileval,v_type,output,reg_timeval))
               dbase.commit()
               messagebox.showinfo('sucess','successfully vaccinated')
          else:
               v_type='Covaxin'
               dbase.execute('INSERT INTO DOSE_DETAILS(NAME,AADHAR_NO,MOBILE_NO,VACCINE_TYPE,DOSES,DATE)VALUES(?,?,?,?,?,?)',(nameval,aadharval,mobileval,v_type,output,reg_timeval))
               dbase.commit()
               messagebox.showinfo('sucess','successfully vaccinated')

          
     elif doseval=='2':
          output='2nd Dose'
          if csvval=='1':
               v_type='CoviShield'
               dbase.execute('INSERT INTO DOSE_DETAILS(NAME,AADHAR_NO,MOBILE_NO,VACCINE_TYPE,DOSES,DATE)VALUES(?,?,?,?,?,?)',(nameval,aadharval,mobileval,v_type,output,reg_timeval))
               dbase.commit()
               messagebox.showinfo('sucess','successfully vaccinated')
          else:
               v_type='Covaxin'
               dbase.execute('INSERT INTO DOSE_DETAILS(NAME,AADHAR_NO,MOBILE_NO,VACCINE_TYPE,DOSES,DATE)VALUES(?,?,?,?,?,?)',(nameval,aadharval,mobileval,v_type,output,reg_timeval))
               dbase.commit()
               messagebox.showinfo('sucess','successfully vaccinated')

     elif doseval=='3':
          output='Booster'
          if csvval=='1':
               v_type='CoviShield'
               dbase.execute('INSERT INTO DOSE_DETAILS(NAME,AADHAR_NO,MOBILE_NO,VACCINE_TYPE,DOSES,DATE)VALUES(?,?,?,?,?,?)',(nameval,aadharval,mobileval,v_type,output,reg_timeval))
               dbase.commit()
               messagebox.showinfo('sucess','successfully vaccinated')
          else:
               v_type='Covaxin'
               dbase.execute('INSERT INTO DOSE_DETAILS(NAME,AADHAR_NO,MOBILE_NO,VACCINE_TYPE,DOSES,DATE)VALUES(?,?,?,?,?,?)',(nameval,aadharval,mobileval,v_type,output,reg_timeval))
               dbase.commit()
               messagebox.showinfo('sucess','successfully vaccinated')

     else:
          print(doseval)
          print(type(doseval))
          messagebox.showerror('Error','select  Dose no:')
     ent1.delete(first=0,last=END)
     ent2.delete(first=0,last=END)
     ent3.delete(first=0,last=END)
      

def search():
      aadhar_searchval=aadhar_search.get()
      cur=dbase.cursor()
      cur.execute("SELECT * FROM DOSE_DETAILS WHERE AADHAR_NO=?",(aadhar_searchval,))
      data=cur.fetchall()

      data_name=data[0][1]
      data_aadhar=data[0][2]
      data_mobile=data[0][3]
      data_type=data[0][4]
      data_dose=data[0][5]
      data_date=data[0][6]
      data=f'''name:{data_name}
Aadhar no:{data_aadhar}
Mobile no:{data_mobile}
Type:{data_type}
Dose :{data_dose}
Date:{data_date}'''
      if data:
            messagebox.showinfo('Search Result',data)
            



lb1=Label(app,text='Name : ',font=('Georgia',28),bg='#6ac2e9',fg='red')
lb1.grid(row=0,column=0,padx=15,pady=15)
ent1=Entry(app,font=('Georgia',28),bg='green',fg='pink',textvariable=name)
ent1.grid(row=0,column=1,padx=15,pady=15)
lb2=Label(app,text='Aadhar No: ',font=('Georgia',28),bg='#6ac2e9',fg='red')
lb2.grid(row=1,column=0,padx=15,pady=15)
ent2=Entry(app,font=('Georgia',28),bg='green',fg='pink',textvariable=aadhar)
ent2.grid(row=1,column=1,padx=15,pady=15)
lb3=Label(app,text='Mobile No: ',font=('Georgia',28),bg='#6ac2e9',fg='red')
lb3.grid(row=2,column=0,padx=15,pady=15)
ent3=Entry(app,font=('Georgia',28),bg='green',fg='pink',textvariable=mobile)
ent3.grid(row=2,column=1,padx=15,pady=15)
lb4=Label(app,text='Select Dose count: ',font=('Georgia',28),bg='#6ac2e9',fg='red')
lb4.grid(row=3,column=0,padx=15,pady=15)
ent5=Radiobutton(app, text="1st Dose",variable=dose,value=1,font=("Georgia",20),bg="skyblue",fg="#663300")
ent5.grid(row=3,column=1,padx=15,pady=15)
ent6=Radiobutton(app, text="2nd Dose",variable=dose,value=2,font=("Georgia",20),bg="skyblue",fg="#663300")
ent6.grid(row=3,column=2,padx=15,pady=15)
ent7=Radiobutton(app, text="Booster",variable=dose,value=3,font=("Georgia",20),bg="skyblue",fg="#663300")
ent7.grid(row=3,column=3,padx=15,pady=15)
lb4=Label(app,text='Vaccine Name: ',font=('Georgia',28),bg='#6ac2e9',fg='red')
lb4.grid(row=4,column=0,padx=15,pady=15)
ent8=Radiobutton(app, text="CoviShield",variable=csv,value=1,font=("Georgia",20),bg="skyblue",fg="#663300")
ent8.grid(row=4,column=1,padx=15,pady=15)
ent9=Radiobutton(app, text="Covaxin",variable=csv,value=0,font=("Georgia",20),bg="skyblue",fg="#663300")
ent9.grid(row=4,column=2,padx=15,pady=15)
lb5=Label(app,text='Quick Details',font=('Georgia',28),bg='#6ac2e9',fg='red')
lb5.grid(row=6,column=0,padx=15,pady=15)
ent10=Entry(app,font=('Georgia',28),bg='green',fg='pink',textvariable=aadhar_search)
ent10.grid(row=6,column=1,padx=15,pady=15)


btn1=Button(app,text='Search',font=('Jokerman',28),bg='#6ac2e9',fg='red',command=search,activebackground='yellow')
btn1.grid(row=6,column=2,padx=15,pady=15)




btn=Button(app,text='submit',font=('Jokerman',28),bg='#6ac2e9',fg='red',command=submit,activebackground='yellow')
btn.grid(row=5,column=1,padx=15,pady=15)




app.mainloop()

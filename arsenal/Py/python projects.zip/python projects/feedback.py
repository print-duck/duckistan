from tkinter import*
from tkinter import messagebox
import sqlite3
dbase=sqlite3.connect('feedback.db')
dbase.execute('''CREATE TABLE IF NOT EXISTS
               STUDENTS(
               ID INTEGER PRIMARY KEY AUTOINCREMENT,
               NAME TEXT NOT NULL,
               DEPT TEXT NOT NULL,
               DOMAIN TEXT NOT NULL,
               FEEDBACK TEXT NOT NULL)''')


app=Tk()
app.title('FEEDBACK')
app.geometry('800x600')
app.configure(background='#6ac2e9')

name=StringVar()
dept=StringVar()
domain=StringVar()
feed=StringVar()

def submit():
      nameval=name.get()
      deptval=dept.get()
      domainval=domain.get()
      feedval=feed.get()
      
      if nameval and deptval and domainval and feedval:
          
           dbase.execute('INSERT INTO STUDENTS(NAME,DEPT,DOMAIN,FEEDBACK)VALUES(?,?,?,?)',(nameval,deptval,domainval,feedval))
           dbase.commit()
           
           messagebox.showinfo('sucess','your have insert successfully')

      else:
           messagebox.showerror("ERROR",'Fill all data')


lb1=Label(app,text='Enter your Name : ',font=('Arial',28),bg='white',fg='red')
lb1.grid(row=0,column=0,padx=15,pady=15)
ent1=Entry(app,font=('Arial',28),bg='#71a8a6',fg='#0f3332',textvariable=name)
ent1.grid(row=0,column=1,padx=15,pady=15)

lb2=Label(app,text='Enter your Dept : ',font=('Arial',28),bg='white',fg='red')
lb2.grid(row=1,column=0,padx=15,pady=15)
ent2=Entry(app,font=('Arial',28),bg='#71a8a6',fg='#0f3332',textvariable=dept)
ent2.grid(row=1,column=1,padx=15,pady=15)

lb3=Label(app,text='Enter your Domain : ',font=('Arial',28),bg='white',fg='red')
lb3.grid(row=2,column=0,padx=15,pady=15)
ent3=Entry(app,font=('Arial',28),bg='#71a8a6',fg='#0f3332',textvariable=domain)
ent3.grid(row=2,column=1,padx=15,pady=15)

lb4=Label(app,text='Enter your Feedback',font=('Arial',28),bg='white',fg='red')
lb4.grid(row=4,column=0,padx=15,pady=15)
ent4=Entry(app,font=('Arial',28),bg='#71a8a6',fg='#0f3332',textvariable=feed)
ent4.grid(row=4,column=1,padx=15,pady=15)

btn=Button(app,text='submit',font=('Arial',28),bg='#6ac2e9',fg='red',command=submit,activebackground='yellow')
btn.grid(row=5,column=1)






          

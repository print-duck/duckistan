from tkinter import*
from tkinter import messagebox as ms
from random import choice


app=Tk()
app.title('Game')
app.geometry('800x600')
app.configure(background='#6ac2e9')






def submit():
    global player


    ai_options='rock','paper','scissor'

    ai_chosen_option=choice(ai_options)
#    print(ai_chosen_option)
    if player == ai_chosen_option :
        a='Draw'
    elif player == 'rock':
        if ai_chosen_option == 'paper':
            a='Computer wins'
        elif ai_chosen_option == 'scissor':
            a='Player Wins'
    elif player == 'paper':
        if ai_chosen_option == 'scissor':
            a='Computer wins'
        elif ai_chosen_option == 'rock':
            a='Player Wins'
    elif player == 'scissor':
        if ai_chosen_option == 'rock':
            a='Computer wins'
        elif ai_chosen_option == 'paper':
            a='Player Wins'
    else:
        ms.showerror('Please enter a valid data')
    ans.configure(text=a)
    ans1.configure(text=ai_chosen_option)


def bt1():
    global player
    player='rock'
    submit()

def bt2():
    global player
    player='paper'
    submit()

def bt3():
    global player
    player='scissor'
    submit()


def qt():
    app.destroy()




btn1=Button(app,text="Rock",command=bt1,font=("Georgia",16),bg="#084a8c",fg="white",activebackground="red",activeforeground="yellow",width=10,bd=5)
btn1.grid(row=0,column=1,padx=15,pady=15)

btn2=Button(app,text="Paper",command=bt2,font=("Georgia",16),bg="#084a8c",fg="white",activebackground="red",activeforeground="yellow",width=10,bd=5)
btn2.grid(row=1,column=1,padx=15,pady=15)

btn3=Button(app,text="Scissor",command=bt3,font=("Georgia",16),bg="#084a8c",fg="white",activebackground="red",activeforeground="yellow",width=10,bd=5)
btn3.grid(row=2,column=1,padx=15,pady=15)


btn4=Button(app,text="Quit",command=qt,font=("Georgia",16),bg="#084a8c",fg="white",activebackground="red",activeforeground="yellow",width=10,bd=5)
btn4.grid(row=4,column=2,padx=15,pady=15)

lb1=Label(app,text="Result",font=("Georgia",26),bg="Red",fg="white")
lb1.grid(row=4,column=0,padx=15,pady=15)

ans=Label(app,font=("Georgia",20),width=40)
ans.grid(row=4,column=1,padx=15,pady=15)

lb2=Label(app,text="Computer",font=("Georgia",26),bg="Red",fg="white")
lb2.grid(row=3,column=0,padx=15,pady=15)

ans1=Label(app,font=("Georgia",20),width=40)
ans1.grid(row=3,column=1,padx=15,pady=15)



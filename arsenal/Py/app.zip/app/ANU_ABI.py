from tkinter import *
from tkinter import messagebox as ms
import sqlite3
from PIL import Image,ImageTk
apl=Tk()
apl.title("LOGIN PAGE")
apl.geometry("800x600")
apl.configure(background="lightpink")


bg_img=Image.open('login.jpeg')
test_img=ImageTk.PhotoImage(bg_img)


bg_img1=Image.open('signin.jpeg')
test_img1=ImageTk.PhotoImage(bg_img1)



dbase=sqlite3.connect("my_app.db")
dbase.execute('''CREATE TABLE IF NOT EXISTS
                ANUABI(
                    ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    NAME TEXT NOT NULL,
                    USERNAME TEXT UNIQUE,
                    PASSWORD TEXT NOT NULL )''')


username1=StringVar()
password1=StringVar()


def login():
     dbase=sqlite3.connect("my_app.db")
     cur=dbase.cursor()
     usernameval=username1.get()
     passwordval=password1.get()

     print(usernameval)
     print(passwordval)

     if usernameval and passwordval:
          cur.execute("SELECT * FROM ANUABI WHERE USERNAME=? AND PASSWORD=?",(usernameval,passwordval))
          data=cur.fetchone()
          if data:
               ms.showinfo("SUCESS","YOU HAVE LOGIN SUCESSFULLY")
          else:
               ms.showinfo("ERROR","INVALID USERNAME OR PASSWORD")
     else:
          ms.showinfo("ERROR","FILL ALL DATA")
     ent1.delete(first=0,last=END)
     ent2.delete(first=0,last=END)          


name=StringVar()     
username=StringVar()
password=StringVar()
confirmpassword=StringVar()

def signup():
     newWindow=Toplevel(apl)
     newWindow.title("signup page")
     newWindow.geometry("800x600")
     newWindow.configure(background='light yellow')
     dbase=sqlite3.connect("my_app.db")

     def submit():
          nameval=name.get()
          usernameval=username.get()
          passwordval=password.get()
          confirm_passwordval=confirmpassword.get()

          if passwordval==confirm_passwordval:
               dbase.execute("INSERT INTO ANUABI(NAME,USERNAME,PASSWORD)VALUES(?,?,?)",(nameval,usernameval,passwordval))
               dbase.commit()
               ms.showinfo("SUCESS","YOUR ACCOUNT CREATED SUCESSFULLY")
               ent1.delete(first=0,last=END)
               ent2.delete(first=0,last=END)
               ent3.delete(first=0,last=END)
               ent4.delete(first=0,last=END)
          else:
               ms.showinfo("ERROR","PASSWORD DON'T MATCH")


     bg_lb1=Label(newWindow,image=test_img1)
     bg_lb1.place(x=0,y=0,relwidth=1,relheight=1)

     
     lb1=Label(newWindow,text="NAME:",font=("ALGERIAN",26),bg="#106394",fg="white")
     lb1.grid(row=0,column=0,padx=15,pady=15)
     ent1=Entry(newWindow,font=("AREIAL",26),bg="white",fg="black",textvariable=name)
     ent1.grid(row=0,column=1,padx=15,pady=15)
     lb2=Label(newWindow,text="USERNAME:",font=("ALGERIAN",26),bg="#106394",fg="white")
     lb2.grid(row=1,column=0,padx=15,pady=15)
     ent2=Entry(newWindow,font=("AREIAL",26),bg="white",fg="black",textvariable=username)
     ent2.grid(row=1,column=1,padx=15,pady=15)
     lb3=Label(newWindow,text="PASSWORD:",font=("ALGERIAN",26),bg="#106394",fg="white")
     lb3.grid(row=2,column=0,padx=15,pady=15)
     ent3=Entry(newWindow,font=("AREIAL",26),bg="white",fg="black",textvariable=password)
     ent3.grid(row=2,column=1,padx=15,pady=15)    
     lb4=Label(newWindow,text="CONFIRM_PASSWORD:",font=("ALGERIAN",26),bg="#106394",fg="white")
     lb4.grid(row=3,column=0,padx=15,pady=15)
     ent4=Entry(newWindow,font=("AREIAL",26),bg="white",fg="black",textvariable=confirmpassword)
     ent4.grid(row=3,column=1,padx=15,pady=15)    

   
     btn1=Button(newWindow,text="SUBMIT",font=("ALGERIAN",20),bg="#245551",fg="white",command=submit,activebackground="Pink")
     btn1.grid(row=4,column=1,padx=15,pady=15)  



     
bg_lb=Label(apl,image=test_img)
bg_lb.place(x=0,y=0,relwidth=1,relheight=1)     



lb1=Label(apl,text="USERNAME:",font=("ALGERIAN",26),bg="#106394",fg="white")
lb1.grid(row=0,column=0,padx=15,pady=15)
ent1=Entry(apl,font=("AREIAL",26),bg="white",fg="black",textvariable=username1)
ent1.grid(row=0,column=1,padx=15,pady=15)
lb2=Label(apl,text="PASSWORD:",font=("ALGERIAN",26),bg="#106394",fg="white")
lb2.grid(row=1,column=0,padx=15,pady=15)
ent2=Entry(apl,font=("AREIAL",26),bg="white",fg="black",textvariable=password1)
ent2.grid(row=1,column=1,padx=15,pady=15)
lb3=Label(apl,text="CREATE NEW ACCOUNT:",font=("ALGERIAN",26),bg="#106394",fg="white")
lb3.grid(row=4,column=0,padx=15,pady=15)





btn1=Button(apl,text="LOGIN",font=("ALGERIAN",20),bg="#245551",fg="white",command=login,activebackground="Pink")
btn1.grid(row=3,column=1,padx=15,pady=15)

btn2=Button(apl,text="SIGNUP",font=("ALGERIAN",20),bg="#245551",fg="white",command=signup,activebackground="Pink")
btn2.grid(row=4,column=1,padx=15,pady=15)









apl.mainloop()











from tkinter import *
from tkinter import messagebox as ms
import sqlite3
from PIL import Image,ImageTk
import random
import time
apl=Tk()
apl.title("LOGIN PAGE")
apl.geometry("800x600")
apl.configure(background="lightpink")


bg_img=Image.open('login.jpeg')
test_img=ImageTk.PhotoImage(bg_img)


bg_img1=Image.open('signin.jpeg')
test_img1=ImageTk.PhotoImage(bg_img1)

bg_img2=Image.open('cngpwd.jpeg')
test_img2=ImageTk.PhotoImage(bg_img2)

bg_img3=Image.open('uppass.jpeg')
test_img3=ImageTk.PhotoImage(bg_img3)



dbase=sqlite3.connect("my_app.db")
dbase.execute('''CREATE TABLE IF NOT EXISTS
                PRAWIN(
                    ID INTEGER PRIMARY KEY AUTOINCREMENT,
                    NAME TEXT NOT NULL,
                    USERNAME TEXT UNIQUE,
                    PASSWORD TEXT NOT NULL,
                    MOBILE_NUMBER INTEGER UNIQUE)''')


username1=StringVar()
password1=StringVar()


def login():
     dbase=sqlite3.connect("my_app.db")
     cur=dbase.cursor()
     usernameval=username1.get()
     passwordval=password1.get()

#     print(usernameval)
#     print(passwordval)

     if usernameval and passwordval:
          cur.execute("SELECT * FROM PRAWIN WHERE USERNAME=? AND PASSWORD=?",(usernameval,passwordval))
          data=cur.fetchone()
          if data:
               ms.showinfo("SUCESS","YOU HAVE LOGIN SUCESSFULLY")
          else:
               ms.showinfo("ERROR","INVALID USERNAME OR PASSWORD")
     else:
          ms.showinfo("ERROR","FILL ALL DATA")
     ent1.delete(first=0,last=END)
     ent2.delete(first=0,last=END)          


name=StringVar()     
username=StringVar()
password=StringVar()
confirmpassword=StringVar()
mobile=StringVar()



def signup():    
     newWindow=Toplevel(apl)
     newWindow.title("signup page")
     newWindow.geometry("800x600")
     newWindow.configure(background='light yellow')
     dbase=sqlite3.connect("my_app.db")

     def submit():
          nameval=name.get()
          usernameval=username.get()
          passwordval=password.get()
          confirm_passwordval=confirmpassword.get()
          mobileval=mobile.get()
          
          try:
               if nameval and usernameval and passwordval and confirm_passwordval and mobileval:
                    if passwordval==confirm_passwordval:
                         dbase.execute("INSERT INTO PRAWIN(NAME,USERNAME,PASSWORD,MOBILE_NUMBER)VALUES(?,?,?,?)",(nameval,usernameval,passwordval,mobileval))
                         dbase.commit()
                         ms.showinfo("SUCESS","YOUR ACCOUNT CREATED SUCESSFULLY")
                         ent1.delete(first=0,last=END)
                         ent2.delete(first=0,last=END)
                         ent3.delete(first=0,last=END)
                         ent4.delete(first=0,last=END)
                         newWindow.destroy()
                    else:
                         ms.showinfo("ERROR","PASSWORD DON'T MATCH")
               else:
                    ms.showinfo("ERROR","FILL ALL DATA")

          except sqlite3.IntegrityError as s:
               ms.showinfo("ERROR","USERNAME ALREADY EXISTS")
               

     bg_lb1=Label(newWindow,image=test_img1)
     bg_lb1.place(x=0,y=0,relwidth=1,relheight=1)

     
     lb1=Label(newWindow,text="NAME:",font=("ALGERIAN",26),bg="#106394",fg="white",relief=RAISED)
     lb1.grid(row=0,column=0,padx=15,pady=15)
     ent1=Entry(newWindow,font=("AREIAL",26),bg="white",fg="black",textvariable=name,relief=RAISED)
     ent1.grid(row=0,column=1,padx=15,pady=15)
     lb2=Label(newWindow,text="USERNAME:",font=("ALGERIAN",26),bg="#106394",fg="white",relief=RAISED)
     lb2.grid(row=1,column=0,padx=15,pady=15)
     ent2=Entry(newWindow,font=("AREIAL",26),bg="white",fg="black",textvariable=username,relief=RAISED)
     ent2.grid(row=1,column=1,padx=15,pady=15)
     lb3=Label(newWindow,text="PASSWORD:",font=("ALGERIAN",26),bg="#106394",fg="white",relief=RAISED)
     lb3.grid(row=2,column=0,padx=15,pady=15)
     ent3=Entry(newWindow, show="*",font=("AREIAL",26),bg="white",fg="black",textvariable=password,relief=RAISED)
     ent3.grid(row=2,column=1,padx=15,pady=15)    
     lb4=Label(newWindow,text="CONFIRM PASSWORD:",font=("ALGERIAN",26),bg="#106394",fg="white",relief=RAISED)
     lb4.grid(row=3,column=0,padx=15,pady=15)
     ent4=Entry(newWindow, show="*",font=("AREIAL",26),bg="white",fg="black",textvariable=confirmpassword,relief=RAISED)
     ent4.grid(row=3,column=1,padx=15,pady=15)
     lb5=Label(newWindow,text="MOBILE NUMBER:",font=("ALGERIAN",26),bg="#106394",fg="white",relief=RAISED)
     lb5.grid(row=4,column=0,padx=15,pady=15)
     ent5=Entry(newWindow,font=("AREIAL",26),bg="white",fg="black",textvariable=mobile,relief=RAISED)
     ent5.grid(row=4,column=1,padx=15,pady=15)

   
     btn1=Button(newWindow,text="SUBMIT",font=("ALGERIAN",20),bg="#245551",fg="white",command=submit,activebackground="yellow",bd=3)
     btn1.grid(row=5,column=1,padx=15,pady=15)  


def forgot():
     global newWindow1
     newWindow1=Toplevel(apl)
     newWindow1.title("forgot password page")
     newWindow1.geometry("800x600")
     newWindow1.configure(background='light blue')
     dbase=sqlite3.connect("my_app.db")

     username=StringVar()
     mobile=StringVar()
     recotp=StringVar()
     



     def genpwd():
          global otp
          global usernameval1
          usernameval1=username.get()
          mobileval=mobile.get()
          cur=dbase.cursor()
          if usernameval1 and mobileval:
               
               cur.execute("SELECT * FROM PRAWIN WHERE USERNAME=? AND MOBILE_NUMBER=?",(usernameval1,mobileval))
               data=cur.fetchone()
               if data:
                    otp=random.randint(1000,10000)
                    print('YOUR OTP: ',otp)
                    ms.showinfo("SUCCESS","YOUR OTP HAS BEEN GENERATED")

               else:
                    ms.showinfo("ERROR","INVALID USERNAME OR MOBILE NUMBER")
          else:
               ms.showinfo("ERROR","FILL ALL DATA")
          


          
     def check():
          otpval=recotp.get()
          if str(otp)==otpval:
               btn5=Button(newWindow1,text="REGISTER",font=("ALGERIAN",20),bg="#245551",fg="white",command=newpass,activebackground="lightblue",bd=3)
               btn5.grid(row=4,column=1,padx=15,pady=15)
          else:
               ms.showinfo("ERROR","PLEASE CHECK OTP")
                    
               
                    

               
          
     bg_lb2=Label(newWindow1,image=test_img2)
     bg_lb2.place(x=0,y=0,relwidth=1,relheight=1)    
     

     lb1=Label(newWindow1,text="USERNAME:",font=("ALGERIAN",26),bg="#106394",fg="white",relief=RAISED)
     lb1.grid(row=0,column=0,padx=15,pady=15)
     ent1=Entry(newWindow1,font=("AREIAL",26),bg="white",fg="black",textvariable=username,relief=RAISED)
     ent1.grid(row=0,column=1,padx=15,pady=15)
     lb2=Label(newWindow1,text="MOBILE NUMBER:",font=("ALGERIAN",26),bg="#106394",fg="white",relief=RAISED)
     lb2.grid(row=1,column=0,padx=15,pady=15)
     ent2=Entry(newWindow1,font=("AREIAL",26),bg="white",fg="black",textvariable=mobile,relief=RAISED)
     ent2.grid(row=1,column=1,padx=15,pady=15)
     lb3=Label(newWindow1,text="ENTER YOUR RECENT OTP:",font=("ALGERIAN",26),bg="#106394",fg="white",relief=RAISED)
     lb3.grid(row=3,column=0,padx=15,pady=15)
     ent3=Entry(newWindow1,font=("AREIAL",26),bg="white",fg="black",textvariable=recotp,relief=RAISED)
     ent3.grid(row=3,column=1,padx=15,pady=15)


     

     
          
     btn4=Button(newWindow1,text="GENERATE OTP",font=("ALGERIAN",20),bg="#245551",fg="white",command=genpwd,activebackground="lightblue",bd=3)
     btn4.grid(row=2,column=1,padx=15,pady=15)
     


     btn6=Button(newWindow1,text="CHECK",font=("ALGERIAN",20),bg="#245551",fg="white",command= check,activebackground="lightblue",bd=3)
     btn6.grid(row=3,column=2,padx=15,pady=15)



def newpass():
     newWindow1.destroy()
     newWindow2=Toplevel(apl)
     newWindow2.title("new password page")
     newWindow2.geometry("800x600")
     newWindow2.configure(background='light blue')
     dbase=sqlite3.connect("my_app.db")


     username=StringVar()
     password=StringVar()
     conformpass=StringVar()


     def newpasssub():
          usernameval=username.get()
          passwordval=password.get()
          conformpassval=conformpass.get()

          cur=dbase.cursor()
          if usernameval and passwordval and conformpassval:
               if passwordval==conformpassval:
                    if usernameval==usernameval1:
                         cur.execute("UPDATE PRAWIN SET PASSWORD = ? WHERE USERNAME = ?",(passwordval,usernameval))
                         dbase.commit()
                         ms.showinfo("SUCCESS","YOUR PASSWORD UPDATED")
                         newWindow2.destroy()
                    else:
                         ms.showinfo("ERROR","INVALID USERNAME OR PASSWORD")
               else:
                    ms.showinfo("ERROR","PASSWORD DON'T ,MATCH")
          else:
               ms.showinfo("ERROR","FILL ALL DATA")
          


     bg_lb3=Label(newWindow2,image=test_img3)
     bg_lb3.place(x=0,y=0,relwidth=1,relheight=1)


     lb1=Label(newWindow2,text="USERNAME:",font=("ALGERIAN",26),bg="#106394",fg="white",relief=RAISED)
     lb1.grid(row=0,column=0,padx=15,pady=15)
     ent1=Entry(newWindow2,font=("AREIAL",26),bg="white",fg="black",textvariable=username,relief=RAISED)
     ent1.grid(row=0,column=1,padx=15,pady=15)
     lb2=Label(newWindow2,text="NEW PASSWORD:",font=("ALGERIAN",26),bg="#106394",fg="white",relief=RAISED)
     lb2.grid(row=1,column=0,padx=15,pady=15)
     ent2=Entry(newWindow2, show="*",font=("AREIAL",26),bg="white",fg="black",textvariable=password,relief=RAISED)
     ent2.grid(row=1,column=1,padx=15,pady=15)
     lb3=Label(newWindow2,text="CONFIRM NEW PASSWORD:",font=("ALGERIAN",26),bg="#106394",fg="white",relief=RAISED)
     lb3.grid(row=2,column=0,padx=15,pady=15)
     ent3=Entry(newWindow2, show="*",font=("AREIAL",26),bg="white",fg="black",textvariable=conformpass,relief=RAISED)
     ent3.grid(row=2,column=1,padx=15,pady=15)

     

     btn6=Button(newWindow2,text="SUBMIT",font=("ALGERIAN",20),bg="#245551",fg="white",command=newpasssub,activebackground="Pink",bd=3)
     btn6.grid(row=3,column=1,padx=15,pady=15)
















     
bg_lb=Label(apl,image=test_img)
bg_lb.place(x=0,y=0,relwidth=1,relheight=1)     



lb1=Label(apl,text="USERNAME:",font=("ALGERIAN",26),bg="#106394",fg="white",relief=RAISED)
lb1.grid(row=0,column=0,padx=15,pady=15)
ent1=Entry(apl,font=("AREIAL",26),bg="white",fg="black",textvariable=username1,relief=RAISED)
ent1.grid(row=0,column=1,padx=15,pady=15)
lb2=Label(apl,text="PASSWORD:",font=("ALGERIAN",26),bg="#106394",fg="white",relief=RAISED)
lb2.grid(row=1,column=0,padx=15,pady=15)
ent2=Entry(apl, show="*",font=("AREIAL",26),bg="white",fg="black",textvariable=password1,relief=RAISED)
ent2.grid(row=1,column=1,padx=15,pady=15)
lb3=Label(apl,text="CREATE NEW ACCOUNT:",font=("ALGERIAN",26),bg="#106394",fg="white",relief=RAISED)
lb3.grid(row=4,column=0,padx=15,pady=15)





btn1=Button(apl,text="LOGIN",font=("ALGERIAN",20),bg="#245551",fg="white",command=login,activebackground="Pink",bd=3)
btn1.grid(row=3,column=1,padx=15,pady=15)

btn2=Button(apl,text="SIGNUP",font=("ALGERIAN",20),bg="#245551",fg="white",command=signup,activebackground="Pink",bd=3)
btn2.grid(row=4,column=1,padx=15,pady=15)

btn3=Button(apl,text="FORGOT_PASSWORD",font=("ALGERIAN",20),bg="#245551",fg="white",command=forgot,activebackground="Pink",bd=3)
btn3.grid(row=3,column=2,padx=15,pady=15)








apl.mainloop()










